// Menu system — read-only. The site's menu lives in data/menu.json so the
// client (or a future admin screen) can edit dishes/prices without
// touching any code.

const express = require('express');
const router = express.Router();
const { readData } = require('../utils/db');

const FILE = 'menu.json';

// GET /api/menu            -> full menu
// GET /api/menu?category=X -> items in one category
router.get('/', (req, res) => {
  const menu = readData(FILE);
  const { category } = req.query;
  if (category) {
    return res.json(menu.filter(item => item.category === category));
  }
  res.json(menu);
});

module.exports = router;
