// Food Ordering system — completely separate from the booking system
// above. Prices are re-looked-up from the menu on the server, so a
// tampered price sent from the browser can never be trusted.

const express = require('express');
const router = express.Router();
const { readData, writeData } = require('../utils/db');

const FILE = 'orders.json';
const MIN_ORDER_AMOUNT = Number(process.env.MIN_ORDER_AMOUNT) || 249;

// GET /api/orders  -> list all orders (used by the admin panel)
router.get('/', (req, res) => {
  const orders = readData(FILE).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  res.json(orders);
});

// POST /api/orders -> place a new order
router.post('/', (req, res) => {
  const { items, customerName, phone, address } = req.body || {};

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Your cart is empty.' });
  }
  if (!customerName || !phone || !address) {
    return res.status(400).json({ error: 'Name, phone and delivery address are required.' });
  }
  if (!/^[0-9+\-\s]{7,15}$/.test(phone)) {
    return res.status(400).json({ error: 'Please enter a valid phone number.' });
  }

  // Re-price every item from the menu — never trust prices sent by the client.
  const menu = readData('menu.json');
  let total = 0;
  const verifiedItems = [];
  for (const line of items) {
    const menuItem = menu.find(m => m.id === line.id);
    if (!menuItem) {
      return res.status(400).json({ error: `Item "${line.id}" is not on the menu.` });
    }
    const qty = Math.max(1, Math.min(20, parseInt(line.qty, 10) || 1));
    total += menuItem.price * qty;
    verifiedItems.push({ id: menuItem.id, name: menuItem.name, price: menuItem.price, qty });
  }

  if (total < MIN_ORDER_AMOUNT) {
    return res.status(400).json({ error: `Minimum order amount is ₹${MIN_ORDER_AMOUNT}.` });
  }

  const orders = readData(FILE);
  const order = {
    id: 'OD' + Date.now(),
    items: verifiedItems,
    total,
    customerName: String(customerName).trim(),
    phone: String(phone).trim(),
    address: String(address).trim(),
    status: 'placed', // placed -> preparing -> out_for_delivery -> delivered / cancelled
    createdAt: new Date().toISOString()
  };

  orders.push(order);
  writeData(FILE, orders);

  res.status(201).json({ message: 'Order placed successfully.', order });
});

// PATCH /api/orders/:id -> update an order's status (admin only, checked in server.js)
router.patch('/:id', (req, res) => {
  const { status } = req.body || {};
  const allowed = ['placed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: 'Invalid status value.' });
  }
  const orders = readData(FILE);
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  order.status = status;
  writeData(FILE, orders);
  res.json({ message: 'Order updated.', order });
});

module.exports = router;
