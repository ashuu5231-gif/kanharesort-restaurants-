// Table Booking system — completely separate from the ordering system
// below, with its own storage file and its own set of endpoints.

const express = require('express');
const router = express.Router();
const { readData, writeData } = require('../utils/db');

const FILE = 'bookings.json';

// GET /api/bookings  -> list all bookings (used by the admin panel)
router.get('/', (req, res) => {
  const bookings = readData(FILE).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  res.json(bookings);
});

// POST /api/bookings -> create a new table booking request
router.post('/', (req, res) => {
  const { name, phone, date, time, guests, occasion, note } = req.body || {};

  if (!name || !phone || !date || !time) {
    return res.status(400).json({ error: 'Name, phone, date and time are required.' });
  }
  if (!/^[0-9+\-\s]{7,15}$/.test(phone)) {
    return res.status(400).json({ error: 'Please enter a valid phone number.' });
  }

  const bookings = readData(FILE);
  const booking = {
    id: 'BK' + Date.now(),
    name: String(name).trim(),
    phone: String(phone).trim(),
    date,
    time,
    guests: guests || '3–4 guests',
    occasion: occasion ? String(occasion).trim() : '',
    note: note ? String(note).trim() : '',
    status: 'pending', // pending -> confirmed -> completed / cancelled
    createdAt: new Date().toISOString()
  };

  bookings.push(booking);
  writeData(FILE, bookings);

  res.status(201).json({ message: 'Booking request received.', booking });
});

// PATCH /api/bookings/:id -> update a booking's status (admin only, checked in server.js)
router.patch('/:id', (req, res) => {
  const { status } = req.body || {};
  const allowed = ['pending', 'confirmed', 'completed', 'cancelled'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: 'Invalid status value.' });
  }
  const bookings = readData(FILE);
  const booking = bookings.find(b => b.id === req.params.id);
  if (!booking) return res.status(404).json({ error: 'Booking not found.' });
  booking.status = status;
  writeData(FILE, bookings);
  res.json({ message: 'Booking updated.', booking });
});

module.exports = router;
