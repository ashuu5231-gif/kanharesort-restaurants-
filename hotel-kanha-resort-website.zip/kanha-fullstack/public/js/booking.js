// Table Booking page logic — submits to the separate /api/bookings system.

document.getElementById('bookingForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('bookingMsg');
  const btn = document.getElementById('submitBtn');
  msg.className = 'form-msg';

  const payload = {
    name: document.getElementById('bname').value.trim(),
    phone: document.getElementById('bphone').value.trim(),
    date: document.getElementById('bdate').value,
    time: document.getElementById('btime').value,
    guests: document.getElementById('bguests').value,
    occasion: document.getElementById('boccasion').value.trim(),
    note: document.getElementById('bnote').value.trim()
  };

  btn.disabled = true; btn.textContent = 'Sending…';

  try {
    const res = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');

    msg.textContent = `✅ Thanks! Your table request (ID: ${data.booking.id}) has been noted — our team will call you to confirm.`;
    msg.classList.add('ok');
    document.getElementById('bookingForm').reset();
  } catch (err) {
    msg.textContent = '❌ ' + err.message;
    msg.classList.add('err');
  } finally {
    btn.disabled = false; btn.textContent = 'Request Table';
  }
});
