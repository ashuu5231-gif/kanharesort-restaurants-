// Food Ordering page logic.
// Fetches the live menu from the backend (GET /api/menu), lets the
// visitor build a cart in the browser, then submits the order to the
// backend (POST /api/orders), which re-checks every price server-side.

let MENU = [];
let cart = {}; // id -> {name, price, qty}

function fmt(n) { return '₹' + n.toLocaleString('en-IN'); }

async function loadMenu() {
  const res = await fetch('/api/menu');
  MENU = await res.json();
  renderCategoryFilter();
  renderMenu('all');
}

function renderCategoryFilter() {
  const categories = ['all', ...new Set(MENU.map(m => m.category))];
  const el = document.getElementById('categoryFilter');
  el.innerHTML = categories.map(c =>
    `<button data-cat="${c}" class="${c === 'all' ? 'active' : ''}">${c === 'all' ? 'All Items' : c}</button>`
  ).join('');
  el.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', () => {
      el.querySelectorAll('button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderMenu(btn.dataset.cat);
    });
  });
}

function renderMenu(category) {
  const items = category === 'all' ? MENU : MENU.filter(m => m.category === category);
  const grid = document.getElementById('menuGrid');
  grid.innerHTML = items.map(item => `
    <div class="item-card">
      <div class="item-photo ${item.photo ? '' : 'placeholder'}">
        ${item.photo ? `<img src="${item.photo}" alt="${item.name}">` : `<span>Photo coming soon</span>`}
      </div>
      <div class="item-body">
        <h3>${item.name}</h3>
        <p>${item.desc}</p>
        <div class="item-row">
          <span class="price">${fmt(item.price)}</span>
          <button class="add-btn" data-id="${item.id}">+ Add</button>
        </div>
      </div>
    </div>
  `).join('');

  grid.querySelectorAll('.add-btn').forEach(btn => {
    btn.addEventListener('click', () => addToCart(btn.dataset.id, btn));
  });
}

function addToCart(id, btn) {
  const item = MENU.find(m => m.id === id);
  if (!item) return;
  if (!cart[id]) cart[id] = { name: item.name, price: item.price, qty: 0 };
  cart[id].qty += 1;
  renderCart();
  if (btn) {
    btn.textContent = 'Added ✓';
    btn.classList.add('added');
    setTimeout(() => { btn.textContent = '+ Add'; btn.classList.remove('added'); }, 900);
  }
}

function renderCart() {
  const itemsEl = document.getElementById('cartItems');
  const ids = Object.keys(cart);
  let total = 0, count = 0;

  if (ids.length === 0) {
    itemsEl.innerHTML = '<p class="cart-empty">Your cart is empty — add a dish or drink to get started.</p>';
  } else {
    itemsEl.innerHTML = ids.map(id => {
      const it = cart[id];
      total += it.price * it.qty;
      count += it.qty;
      return `<div class="cart-item">
        <div><div class="cart-item-name">${it.name} × ${it.qty}</div><div class="cart-item-price">${fmt(it.price)} each</div></div>
        <button class="cart-item-remove" data-id="${id}">Remove</button>
      </div>`;
    }).join('');
  }

  document.getElementById('cartTotal').textContent = fmt(total);
  document.getElementById('cartBarCount').textContent = count;
  document.getElementById('cartBarTotal').textContent = fmt(total);
  const dot = document.getElementById('cartDot');
  dot.textContent = count;
  dot.classList.toggle('show', count > 0);
  document.getElementById('cartBar').classList.toggle('show', count > 0);

  itemsEl.querySelectorAll('.cart-item-remove').forEach(btn => {
    btn.addEventListener('click', () => { delete cart[btn.dataset.id]; renderCart(); });
  });
}

const cartDrawer = document.getElementById('cartDrawer');
const cartOverlay = document.getElementById('cartOverlay');
function openCart() { cartDrawer.classList.add('open'); cartOverlay.classList.add('open'); }
function closeCart() { cartDrawer.classList.remove('open'); cartOverlay.classList.remove('open'); }
document.getElementById('cartOpenBtn').addEventListener('click', openCart);
document.getElementById('cartBarBtn').addEventListener('click', openCart);
document.getElementById('cartClose').addEventListener('click', closeCart);
cartOverlay.addEventListener('click', closeCart);

document.getElementById('checkoutBtn').addEventListener('click', async () => {
  const msg = document.getElementById('checkoutMsg');
  msg.className = 'form-msg';
  const items = Object.entries(cart).map(([id, it]) => ({ id, qty: it.qty }));
  const customerName = document.getElementById('custName').value.trim();
  const phone = document.getElementById('custPhone').value.trim();
  const address = document.getElementById('custAddress').value.trim();

  if (items.length === 0) { msg.textContent = 'Your cart is empty.'; msg.classList.add('err'); return; }
  if (!customerName || !phone || !address) { msg.textContent = 'Please fill in name, phone and address.'; msg.classList.add('err'); return; }

  const btn = document.getElementById('checkoutBtn');
  btn.disabled = true; btn.textContent = 'Placing order…';

  try {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items, customerName, phone, address })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');

    msg.textContent = `✅ Order placed! Order ID: ${data.order.id} — we'll call to confirm delivery.`;
    msg.classList.add('ok');
    cart = {};
    renderCart();
    setTimeout(closeCart, 2500);
  } catch (err) {
    msg.textContent = '❌ ' + err.message;
    msg.classList.add('err');
  } finally {
    btn.disabled = false; btn.textContent = 'Place Order';
  }
});

loadMenu();
