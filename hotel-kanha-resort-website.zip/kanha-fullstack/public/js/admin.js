// Admin dashboard — asks for the ADMIN_KEY (set in the server's .env file),
// then loads bookings and orders using that key in the "x-admin-key" header.
// The key is kept only in sessionStorage (cleared when the tab closes).

const gate = document.getElementById('adminGate');
const panel = document.getElementById('adminPanel');

function getKey() { return sessionStorage.getItem('kanha_admin_key'); }

async function tryLoad() {
  const key = getKey();
  if (!key) return;
  const ok = await loadAll(key);
  if (ok) { gate.style.display = 'none'; panel.style.display = 'block'; }
  else { sessionStorage.removeItem('kanha_admin_key'); }
}

document.getElementById('adminLoginBtn').addEventListener('click', async () => {
  const key = document.getElementById('adminKeyInput').value;
  const msg = document.getElementById('adminLoginMsg');
  msg.textContent = '';
  const ok = await loadAll(key);
  if (ok) {
    sessionStorage.setItem('kanha_admin_key', key);
    gate.style.display = 'none';
    panel.style.display = 'block';
  } else {
    msg.textContent = 'Incorrect admin key.';
  }
});

document.getElementById('logoutBtn').addEventListener('click', () => {
  sessionStorage.removeItem('kanha_admin_key');
  location.reload();
});

async function loadAll(key) {
  try {
    const [bookingsRes, ordersRes] = await Promise.all([
      fetch('/api/bookings', { headers: { 'x-admin-key': key } }),
      fetch('/api/orders', { headers: { 'x-admin-key': key } })
    ]);
    if (bookingsRes.status === 401 || ordersRes.status === 401) return false;
    const bookings = await bookingsRes.json();
    const orders = await ordersRes.json();
    renderBookings(bookings, key);
    renderOrders(orders, key);
    return true;
  } catch (e) {
    return false;
  }
}

function statusOptions(current, list) {
  return list.map(s => `<option value="${s}" ${s === current ? 'selected' : ''}>${s}</option>`).join('');
}

function renderBookings(bookings, key) {
  const tbody = document.querySelector('#bookingsTable tbody');
  const statuses = ['pending', 'confirmed', 'completed', 'cancelled'];
  tbody.innerHTML = bookings.map(b => `
    <tr>
      <td>${b.id}</td>
      <td>${b.name}</td>
      <td>${b.phone}</td>
      <td>${b.date} ${b.time}</td>
      <td>${b.guests}</td>
      <td>${b.occasion || '—'}</td>
      <td>${b.note || '—'}</td>
      <td><select class="admin-select" data-id="${b.id}" data-type="bookings">${statusOptions(b.status, statuses)}</select></td>
    </tr>
  `).join('') || `<tr><td colspan="8" style="color:var(--sage);">No bookings yet.</td></tr>`;
  bindStatusSelects(key);
}

function renderOrders(orders, key) {
  const tbody = document.querySelector('#ordersTable tbody');
  const statuses = ['placed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled'];
  tbody.innerHTML = orders.map(o => `
    <tr>
      <td>${o.id}</td>
      <td>${o.customerName}</td>
      <td>${o.phone}</td>
      <td>${o.address}</td>
      <td>${o.items.map(i => `${i.name} ×${i.qty}`).join(', ')}</td>
      <td>₹${o.total}</td>
      <td><select class="admin-select" data-id="${o.id}" data-type="orders">${statusOptions(o.status, statuses)}</select></td>
    </tr>
  `).join('') || `<tr><td colspan="7" style="color:var(--sage);">No orders yet.</td></tr>`;
  bindStatusSelects(key);
}

function bindStatusSelects(key) {
  document.querySelectorAll('.admin-select').forEach(sel => {
    sel.onchange = async () => {
      const { id, type } = sel.dataset;
      await fetch(`/api/${type}/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': key },
        body: JSON.stringify({ status: sel.value })
      });
    };
  });
}

tryLoad();
