// Simple shared-password protection for admin-only actions:
//  - viewing the bookings/orders list is public-ish inside /api but the
//    admin PAGE itself asks for the key, and every status-changing
//    request must include it in the "x-admin-key" header.
// This is basic protection suitable for a small single-admin site.
// If the resort later wants per-staff logins, swap this for real
// authentication (e.g. sessions + hashed passwords).

function requireAdminKey(req, res, next) {
  const key = req.header('x-admin-key');
  if (!process.env.ADMIN_KEY) {
    return res.status(500).json({ error: 'Server misconfigured: ADMIN_KEY is not set.' });
  }
  if (key !== process.env.ADMIN_KEY) {
    return res.status(401).json({ error: 'Invalid admin key.' });
  }
  next();
}

module.exports = { requireAdminKey };
