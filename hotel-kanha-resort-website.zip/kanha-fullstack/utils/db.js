// Tiny JSON-file "database" helper.
// Good enough for a small resort's booking/order volume without needing
// a full database server. Swap for MongoDB/PostgreSQL later if the
// business grows and needs multi-device concurrent writes.

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');

function filePath(file) {
  return path.join(DATA_DIR, file);
}

function readData(file) {
  const p = filePath(file);
  if (!fs.existsSync(p)) return [];
  const raw = fs.readFileSync(p, 'utf-8').trim();
  return raw ? JSON.parse(raw) : [];
}

function writeData(file, data) {
  fs.writeFileSync(filePath(file), JSON.stringify(data, null, 2));
}

module.exports = { readData, writeData };
